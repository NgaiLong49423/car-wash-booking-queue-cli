# GitHub Issue Draft Index

## Summary
- Source documents:
  - docs/requirements/PRD.md
  - docs/requirements/SRS.md (Source of Truth)
- Draft output directory: `.agent/report/github-issue-drafts/`
- Mode: Draft only
- Real GitHub issues created: No
- GitHub Project synced: No
- Target GitHub Project: Project 12 (`Personal Software Project Board Template`)

## Functional Requirements (FR) Traceability Table

| No | Draft File | Title | Type | Size | SP | Priority | Source Trace | Dependencies | Relationships | Labels | Suggested Branch | Status |
|---|---|---|---|---|---:|---|---|---|---|---|---|---|
| 001 | [001-foundation-custom-data-structures.md](001-foundation-custom-data-structures.md) | `[Foundation][DS] Implement Custom Data Structures` | ⚙️ Backend | M | 3 | `⬆️ High` | Section 7 | None | Blocking: 002-015 | 🛠️ Backend, 📋 Task, 🔴 priority-high | `backend/custom-data-structures` | Draft |
| 002 | [002-persistence-file-storage.md](002-persistence-file-storage.md) | `[Persistence][FR-22/23/25] Implement File Storage and Seed Data Initialization` | ✨ Feature | M | 3 | `⬆️ High` | FR-22, 23, 25 | Blocked by: 001 | Blocking: 003-015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `backend/file-persistence` | Draft |
| 003 | [003-entities-customer-management.md](003-entities-customer-management.md) | `[Entities][FR-01] Implement Customer Profile Management` | ✨ Feature | M | 3 | `➡️ Medium` | FR-01, 24, UC-07 | Blocked by: 001, 002 | Blocking: 004, 007, 015 | 🚀 Feature, 🛠️ Backend, 🟠 priority-medium | `feature/customer-management` | Draft |
| 004 | [004-entities-vehicle-management.md](004-entities-vehicle-management.md) | `[Entities][FR-02] Implement Vehicle Owner Linkage and Search` | ✨ Feature | S | 2 | `➡️ Medium` | FR-02, 24, UC-08 | Blocked by: 001-003 | Blocking: 007, 015 | 🚀 Feature, 🛠️ Backend, 🟠 priority-medium | `feature/vehicle-management` | Draft |
| 005 | [005-entities-service-management.md](005-entities-service-management.md) | `[Entities][FR-03] Implement Service Configuration with Selection Sort` | ✨ Feature | S | 2 | `➡️ Medium` | FR-03, 24, UC-09 | Blocked by: 001, 002 | Blocking: 007, 015 | 🚀 Feature, 🛠️ Backend, 🟠 priority-medium | `feature/service-management` | Draft |
| 006 | [006-simulation-time-settings.md](006-simulation-time-settings.md) | `[Simulation][FR-04] Implement Simulation Time Settings` | ✨ Feature | XS | 1 | `➡️ Medium` | FR-04, UC-10 | Blocked by: 001, 002 | Blocking: 007, 015 | 🚀 Feature, 🛠️ Backend, 🟠 priority-medium | `feature/simulation-time` | Draft |
| 007 | [007-booking-creation-validation.md](007-booking-creation-validation.md) | `[Booking][FR-05/06/07/08/09] Implement Booking Creation and Validation` | ✨ Feature | L | 5 | `⬆️ High` | FR-05, 06, 07, 08, 09, UC-03 | Blocked by: 001-006 | Blocking: 008, 009, 010, 012, 015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/booking-creation` | Draft |
| 008 | [008-queue-period-activation.md](008-queue-period-activation.md) | `[Queue][FR-10/11] Implement Service Period Activation` | ✨ Feature | M | 3 | `⬆️ High` | FR-10, 11, UC-11 | Blocked by: 007 | Blocking: 009, 010, 011, 012, 015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/period-activation` | Draft |
| 009 | [009-queue-view-monitoring.md](009-queue-view-monitoring.md) | `[View][FR-12/13/14] Implement Queue Monitoring and Customer Bookings Views` | ✨ Feature | S | 2 | `➡️ Medium` | FR-12, 13, 14, UC-04, 12 | Blocked by: 008 | Blocking: 015 | 🚀 Feature, 🛠️ Backend, 🟠 priority-medium | `feature/queue-history-views` | Draft |
| 010 | [010-process-service-processing.md](010-process-service-processing.md) | `[Process][FR-15/16] Implement Service Processing and Payment Confirmation` | ✨ Feature | S | 2 | `⬆️ High` | FR-15, 16, UC-13, 14 | Blocked by: 007, 008 | Blocking: 011, 015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/service-processing` | Draft |
| 011 | [011-completion-booking-completion.md](011-completion-booking-completion.md) | `[Completion][FR-17/19] Implement Booking Completion and Loyalty Recalculation` | ✨ Feature | L | 5 | `⬆️ High` | FR-17, 19, UC-15 | Blocked by: 010 | Blocking: 013, 014, 015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/booking-completion` | Draft |
| 012 | [012-cancellation-booking-cancellation.md](012-cancellation-booking-cancellation.md) | `[Cancellation][FR-18] Implement Booking Cancellation and Queue Promotion` | ✨ Feature | M | 3 | `⬆️ High` | FR-18, UC-05 | Blocked by: 007, 008 | Blocking: 014, 015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/booking-cancellation` | Draft |
| 013 | [013-history-view.md](013-history-view.md) | `[History][FR-20] Implement Global and Customer History Reports` | ✨ Feature | S | 2 | `➡️ Medium` | FR-20, UC-06, 16 | Blocked by: 011 | Blocking: 015 | 🚀 Feature, 🛠️ Backend, 🟠 priority-medium | `feature/history-reports` | Draft |
| 014 | [014-undo-booking-rollback.md](014-undo-booking-rollback.md) | `[Undo][FR-21] Implement Undo Last Completed Booking` | ✨ Feature | M | 3 | `⬆️ High` | FR-21, UC-17 | Blocked by: 011, 012 | Blocking: 015 | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/undo-booking` | Draft |
| 015 | [015-cli-menu-integration.md](015-cli-menu-integration.md) | `[CLI][FR-26] Implement CLI Menus and System Integration` | ✨ Feature | M | 3 | `⬆️ High` | FR-26 | Blocked by: 001-014 | None | 🚀 Feature, 🛠️ Backend, 🔴 priority-high | `feature/cli-menu-integration` | Draft |
