# [Process][FR-15/FR-16] Implement CLI Service Processing and Payment Confirmation

## Tóm tắt
Triển khai nghiệp vụ chuyển đổi trạng thái phục vụ bao gồm gọi xe tiếp theo vào vị trí rửa (chuyển trạng thái booking đầu Main Queue từ `WAITING` sang `SERVING`) và xác nhận thanh toán mô phỏng cho booking đang phục vụ (`UNPAID -> PAID`).

## Source Trace
- PRD: FR-15, FR-16, Mục 7.7 (Booking Status)
- SRS/Spec: FR-15, FR-16, UC-13, UC-14, Mục 3.10 (Quy tắc hủy booking), Mục 3.14 (Quy tắc trạng thái booking)

## Mục tiêu
Quản lý luồng chuyển đổi trạng thái rửa xe tuần tự tại tiệm và mô phỏng xác nhận giao dịch tài chính trước khi hoàn tất dịch vụ.

## Phạm vi
- Triển khai chức năng "Xử lý booking tiếp theo":
  - Kiểm tra xem hiện tại trong tiệm có booking nào đang ở trạng thái `SERVING` hay chưa. Nếu có, báo lỗi và từ chối.
  - Lấy phần tử đứng đầu Main Queue (MyQueue.dequeue).
  - Chuyển trạng thái booking đó từ `WAITING` sang `SERVING`.
  - Cập nhật file `bookings.txt`.
- Triển khai chức năng "Xác nhận thanh toán":
  - Tìm kiếm booking đang ở trạng thái `SERVING` trong bộ nhớ RAM.
  - Hiển thị thông tin dịch vụ, giá tiền cần thu.
  - Cho phép Admin chọn phương thức thanh toán (`CASH` hoặc `BANKING`).
  - Ghi nhận trạng thái thanh toán của booking thành `PAID` và phương thức thanh toán tương ứng.
  - Cập nhật file `bookings.txt`.

## Không nằm trong phạm vi
- Không xử lý thanh toán thực tế qua cổng ngân hàng.
- Không tự động kích hoạt chuyển trạng thái booking sang `COMPLETED` tại bước thanh toán này.

## Quy tắc nghiệp vụ / Yêu cầu liên quan
- Tại một thời điểm chỉ có tối đa 1 booking ở trạng thái `SERVING` hoạt động.
- Chỉ cho phép xác nhận thanh toán cho booking đang ở trạng thái `SERVING`.
- Phương thức thanh toán hợp lệ là `CASH` hoặc `BANKING`.

## Implementation Notes
Cần đảm bảo hàm kiểm tra `hasActiveServingBooking()` hoạt động chuẩn xác bằng cách duyệt danh sách booking để ngăn chặn lỗi vận hành rửa song song 2 xe.

## Acceptance Criteria
- [ ] Chức năng gọi xe tiếp theo lấy đúng xe đứng đầu Main Queue (theo nguyên tắc vào trước ra trước), đổi trạng thái thành `SERVING`.
- [ ] Báo lỗi và không cho phép gọi xe mới nếu trong hệ thống đã có 1 xe đang ở trạng thái `SERVING`.
- [ ] Xác nhận thanh toán thành công chuyển trạng thái thanh toán của booking `SERVING` thành `PAID`.
- [ ] Từ chối xác nhận thanh toán nếu không tìm thấy xe nào đang rửa (`SERVING`).
- [ ] Sau mỗi thao tác đổi trạng thái hoặc thanh toán, ghi nhận thành công xuống file `bookings.txt` lập tức.

## Project Metadata
- Type: ✨ Feature (ID: 92e50fe6)
- Size: S
- Story Points: 2
- Estimation Reason: Logic xử lý các trạng thái đơn giản tuần tự trên Queue và cập nhật thuộc tính đối tượng trong RAM. Rủi ro logic thấp.
- Priority: ⬆️ High (ID: 06f6c1b8)
- Priority Reason: Cần thiết để chuẩn bị cho giao dịch hoàn tất dịch vụ ở issue tiếp theo.
- Start Date: TBD
- Target Date: TBD

## Labels
- 🚀 Feature
- 🛠️ Backend
- 🔴 priority-high

## Relationships
- Parent: None
- Blocked by: 007-booking-creation-validation.md, 008-queue-period-activation.md
- Blocking: 011-completion-booking-completion.md, 014-cli-menu-integration.md
- Security alert: None

## Suggested Branch
`feature/service-processing`

## Ghi chú cho người thực hiện
- Khi gọi xe tiếp theo, in rõ thông tin biển số xe và tên khách hàng lên màn hình để nhân viên biết xe nào cần đánh vào tiệm rửa.
