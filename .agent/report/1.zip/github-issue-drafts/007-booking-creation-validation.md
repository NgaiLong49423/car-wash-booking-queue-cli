# [Booking][FR-05/FR-06/FR-07/FR-08/FR-09] Implement Booking Creation and Window Validation by Member Tier

## Tóm tắt
Triển khai chức năng tạo booking mới cho khách hàng (Customer tự đặt hoặc Admin đặt hộ) kèm theo kiểm tra chặt chẽ các ràng buộc về ngày đặt tối đa (booking window) theo hạng thành viên và kiểm tra tổng sức chứa của buổi phục vụ được đặt lịch.

## Source Trace
- PRD: FR-05, FR-06, FR-07, FR-08, FR-09, Mục 7.4 (Booking Window), Mục 7.5 (Booking hiện tại/tương lai)
- SRS/Spec: FR-05, FR-06, FR-07, FR-08, FR-09, UC-03, Mục 3.4 (Booking window), Mục 3.5 (Booking hiện tại), Mục 3.6 (Booking tương lai)

## Mục tiêu
Đảm bảo booking được tiếp nhận đúng quy trình, thực thi công bằng các đặc quyền ưu tiên đặt trước theo tier và kiểm tra dung lượng buổi để ngăn chặn đặt lịch vượt sức chứa của tiệm.

## Phạm vi
- Tạo lớp thực thể `Booking` chứa các trường thông tin quy định tại SRS Mục 6.4: mã booking (`id`), `customerId`, `vehicleId`, `serviceId`, ngày đặt (`bookingDate`), buổi đặt (`period`), trạng thái booking (`status`), trạng thái thanh toán (`paymentStatus`), phương thức thanh toán (`paymentMethod`), thời điểm tạo booking (`createdAt`).
- Tự động sinh mã booking tăng dần theo định dạng `B001, B002...` dựa trên ID lớn nhất hiện tại.
- Triển khai kiểm tra logic liên kết: Khách hàng phải tồn tại, Xe phải tồn tại và Xe bắt buộc phải thuộc sở hữu của khách hàng đó.
- Triển khai kiểm tra **Booking window**: Tính khoảng cách số ngày giữa ngày muốn đặt lịch và ngày hiện tại mô phỏng (`currentDate`). Từ chối booking nếu vượt quá giới hạn ngày đặt trước tối đa tương ứng với hạng thành viên hiện tại của khách hàng.
- Triển khai phân loại và kiểm tra sức chứa buổi:
  - Nếu buổi đặt lịch là **buổi tương lai** hoặc buổi hiện tại **chưa được kích hoạt**: Kiểm tra tổng sức chứa của buổi đó (Sức chứa slot chính + Sức chứa slot chờ phụ). Nếu còn chỗ thì nhận booking ở trạng thái `WAITING` (được coi là booking tương lai chờ kích hoạt). Nếu đầy, từ chối tạo.
  - Nếu buổi đặt lịch là **buổi hiện tại đã được kích hoạt**:
    - Nếu slot chính của buổi phục vụ còn chỗ trống: xếp booking vào cuối hàng chờ chính (FIFO Queue).
    - Nếu slot chính đã đầy nhưng hàng chờ phụ (Waitlist) còn chỗ trống: đưa booking vào hàng chờ phụ (Priority Queue).
    - Nếu cả hai đều đầy: từ chối booking.
- Lưu dữ liệu booking mới tạo xuống file `bookings.txt`.

## Không nằm trong phạm vi
- Issue này chỉ xử lý tạo booking, không triển khai tính năng thanh toán, hủy hay hoàn tất booking.
- Admin không được override quy tắc booking window hay sức chứa buổi của tiệm.

## Quy tắc nghiệp vụ / Yêu cầu liên quan
- Giới hạn ngày đặt trước tối đa (booking window):
  - Member: tối đa 7 ngày.
  - Silver: tối đa 10 ngày.
  - Gold: tối đa 12 ngày.
  - Platinum: tối đa 14 ngày.
- Giới hạn sức chứa cứng theo buổi:
  - MORNING: 10 slot chính, 3 slot chờ phụ (Tổng sức chứa = 13).
  - AFTERNOON: 10 slot chính, 3 slot chờ phụ (Tổng sức chứa = 13).
  - EVENING: 5 slot chính, 2 slot chờ phụ (Tổng sức chứa = 7).

## Implementation Notes
Sử dụng `MyMap` hoặc mảng tra cứu đơn giản để kiểm tra giới hạn booking window của khách hàng nhanh chóng. Lưu giữ thời gian tạo booking (`createdAt`) chính xác theo mili-giây hoặc định dạng mô phỏng để sắp xếp độ ưu tiên Waitlist sau này.

## Acceptance Criteria
- [ ] Booking tạo thành công sinh mã dạng `BXXX` tăng dần bắt đầu bằng `B001`.
- [ ] Từ chối tạo booking nếu xe chọn không thuộc sở hữu của khách hàng đặt lịch.
- [ ] Từ chối tạo booking nếu ngày đặt nằm ngoài khoảng booking window của hạng thành viên khách hàng (Ví dụ: khách hạng Member cố tình đặt lịch trước 8 ngày bị từ chối).
- [ ] Booking đặt cho buổi tương lai thành công khi tổng số booking hiện tại của buổi đó nhỏ hơn giới hạn sức chứa cứng (Ví dụ: đặt cho buổi Sáng tương lai thứ 14 của Platinum thành công nếu tổng số booking của buổi đó $< 13$).
- [ ] Nếu buổi hiện tại đã kích hoạt, booking đặt ngay trong buổi được phân bổ đúng vào Main Queue (nếu slot chính còn chỗ), hoặc đưa vào Waitlist (nếu slot chính đầy và waitlist còn chỗ). Hiển thị rõ vị trí xếp chỗ cho người dùng.
- [ ] Ghi dữ liệu booking mới xuống file `bookings.txt` lập tức.

## Project Metadata
- Type: ✨ Feature (ID: 92e50fe6)
- Size: L
- Story Points: 5
- Estimation Reason: Logic đặt lịch có độ phức tạp cao, đòi hỏi tích hợp nhiều quy tắc nghiệp vụ kiểm tra chéo (Customer, Vehicles, Services, Simulation Time, Booking Window, Sức chứa buổi và trạng thái Kích hoạt). Giữ nguyên quy mô lớn để bảo trì tính nhất quán của luồng nghiệp vụ.
- Priority: ⬆️ High (ID: 06f6c1b8)
- Priority Reason: Luồng nghiệp vụ cốt lõi, là đầu vào dữ liệu cho toàn bộ các chức năng xếp hàng và điều phối phục vụ phía sau.
- Start Date: TBD
- Target Date: TBD

## Labels
- 🚀 Feature
- 🛠️ Backend
- 🔴 priority-high

## Relationships
- Parent: None
- Blocked by: 001-foundation-custom-data-structures.md, 002-persistence-file-storage.md, 003-entities-customer-management.md, 004-entities-vehicle-linkage.md, 005-entities-service-management.md, 006-simulation-time-settings.md
- Blocking: 008-queue-period-activation.md, 009-view-queue-history-views.md, 010-process-service-processing.md, 012-cancellation-booking-cancellation.md, 014-cli-menu-integration.md
- Security alert: None

## Suggested Branch
`feature/booking-creation`

## Ghi chú cho người thực hiện
- Đảm bảo kiểm tra khoảng cách ngày chính xác bằng cách parse chuỗi ngày thành số ngày (epoch days) để trừ trực quan, tránh lỗi chênh lệch múi giờ.
- Viết thông báo phản hồi chi tiết sau khi tạo booking thành công chỉ rõ xe nằm ở "Slot chính", "Hàng chờ phụ" hay "Booking tương lai".
