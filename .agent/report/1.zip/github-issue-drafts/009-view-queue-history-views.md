# [View][FR-12/FR-13/FR-14/FR-20] Implement CLI Queue Monitoring, History Reports, and Customer Views

## Tóm tắt
Triển khai các giao diện xem và theo dõi hàng chờ (Main Queue, Waitlist), tra cứu danh sách booking chưa kết thúc của khách hàng, và xem lịch sử rửa xe của tiệm (hoặc lịch sử cá nhân) trên giao diện CLI.

## Source Trace
- PRD: FR-12, FR-13, FR-14, FR-20, Mục 11.2 (Customer Menu), Mục 11.3 (Admin Menu)
- SRS/Spec: FR-12, FR-13, FR-14, FR-20, UC-04, UC-06, UC-12, UC-16, Mục 9.4 (Nguyên tắc hiển thị thông báo)

## Mục tiêu
Cung cấp thông tin trực quan cho khách hàng và nhân viên về vị trí xếp hàng phục vụ, danh sách lịch sử rửa xe, giúp theo dõi vận hành tiệm dễ dàng.

## Phạm vi
- Triển khai chức năng xem hàng chờ buổi hiện tại (đã kích hoạt):
  - Hiển thị danh sách xe đang nằm trong **Main Queue** theo thứ tự FIFO (duyệt từ đầu đến cuối hàng đợi).
  - Hiển thị danh sách xe đang nằm trong **Waitlist** theo đúng thứ tự ưu tiên trong Max Heap.
- Triển khai chức năng xem booking chưa kích hoạt (booking tương lai) của buổi chưa kích hoạt.
- Triển khai chức năng xem booking cá nhân của khách hàng (chỉ lọc các booking đang ở trạng thái `WAITING` hoặc `SERVING` của `currentCustomer`).
- Triển khai chức năng xem lịch sử rửa xe: hiển thị danh sách các booking ở trạng thái `COMPLETED` nạp từ `history.txt`. Hỗ trợ lọc theo mã khách hàng (cho Customer xem lịch sử cá nhân hoặc Admin kiểm tra).

## Không nằm trong phạm vi
- Không cho phép chỉnh sửa trạng thái booking hay thông tin thanh toán trong các màn hình xem/tra cứu này.

## Quy tắc nghiệp vụ / Yêu cầu liên quan
- Chỉ hiển thị các booking chưa kết thúc (`WAITING` và `SERVING`) trong chức năng xem booking của khách hàng.
- Lịch sử rửa xe chỉ ghi nhận các booking đã hoàn tất ở trạng thái `COMPLETED`. Booking bị hủy khi đang `SERVING` không được đưa vào lịch sử.

## Implementation Notes
Duyệt qua các cấu trúc dữ liệu tự định nghĩa: duyệt node trên `MyQueue` và duyệt cây Max Heap trong `MyPriorityQueue` mà không phá hủy cấu trúc của chúng (dùng phương thức duyệt hoặc copy tạm ra mảng để sắp xếp hiển thị).

## Acceptance Criteria
- [ ] Xem hàng chờ buổi hiện tại hiển thị đầy đủ thông tin: Mã booking, Biển số xe, Tên dịch vụ, Hạng thành viên, Trạng thái booking, và phân loại rõ ràng mục "Slot chính" và mục "Hàng chờ phụ".
- [ ] Chức năng xem booking của tôi chỉ hiển thị đúng các booking `WAITING` hoặc `SERVING` của riêng khách hàng đang đăng nhập bằng ID.
- [ ] Chức năng xem lịch sử hiển thị đầy đủ thông tin các booking đã `COMPLETED` trong `history.txt` (Mã booking, biển số xe, số tiền thanh toán, điểm loyalty cộng thêm, thời điểm hoàn tất).
- [ ] Hiển thị sức chứa dưới dạng phân số "số chỗ đã dùng / tổng sức chứa" (Ví dụ: `MORNING: 12/13 slots`).

## Project Metadata
- Type: ✨ Feature (ID: 92e50fe6)
- Size: S
- Story Points: 2
- Estimation Reason: Tập trung chủ yếu vào logic lọc và định dạng văn bản hiển thị dữ liệu từ RAM/file. Không thay đổi trạng thái nghiệp vụ nên rủi ro thấp.
- Priority: ➡️ Medium (ID: 17b09fd9)
- Priority Reason: Giúp người dùng và nhà phát triển kiểm chứng trực quan kết quả phân bổ hàng chờ của kích hoạt buổi ở issue trước.
- Start Date: TBD
- Target Date: TBD

## Labels
- 🚀 Feature
- 🛠️ Backend
- 🟠 priority-medium

## Relationships
- Parent: None
- Blocked by: 007-booking-creation-validation.md, 008-queue-period-activation.md
- Blocking: 014-cli-menu-integration.md
- Security alert: None

## Suggested Branch
`feature/queue-history-views`

## Ghi chú cho người thực hiện
- Sử dụng căn lề chữ (printf định dạng bảng) trong CLI để thông tin hàng chờ hiển thị đẹp mắt và chuyên nghiệp.
- Khi in Waitlist, lưu ý in đúng thứ tự ưu tiên của Max Heap (có thể lấy bản sao của Heap rồi thực hiện poll liên tiếp để hiển thị đúng thứ tự ưu tiên từ cao xuống thấp).
