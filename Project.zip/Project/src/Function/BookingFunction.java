/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Function;

import dto.Booking;
import dto.Customer;
import dto.Node;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class BookingFunction {
    Scanner sc = new Scanner(System.in);
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    LocalDate now = LocalDate.now();
    public void addBooking(List l,Customer c){
        int id;
        int carid;
        String date;
        LocalDate bookingdate;
        
        System.out.print("Booking id: ");
        id = sc.nextInt();
        System.out.print("Car id: ");
        carid = sc.nextInt();
        sc.nextLine();
        System.out.print("Date(dd/MM/yyyy): ");
        date = sc.nextLine();
        bookingdate = LocalDate.parse(date, formatter);
        Booking b = new Booking(id, c.getCusid(), carid, bookingdate, "Waiting", 200000);
        if(l.findInfo(id,c.getCusid())==null && l.findDate(date)){
            l.add(b);
        }else if(!l.findDate(date)){
            System.out.println("Date is full");
        }else{
            System.out.println("Id already exist.");
        }
        
    }
    
    public boolean payment(int bookingid,List l,Customer c){
        if(l.findInfo(bookingid,c.getCusid())!=null && l.findInfo(bookingid,c.getCusid()).info.getStatus().equalsIgnoreCase("serving")){
            System.out.print("Confirm payment?(Y/N)");
            String choice = sc.nextLine();
            if(choice.equalsIgnoreCase("y")){
                    l.findInfo(bookingid,c.getCusid()).info.setStatus("Completed");
                    return true;
            }else{
                System.out.println("Payment canceled");
            }
        }else{
            System.err.println("No valid booking found");
        }
        return false;
    }
    
    public void undo(int bookingid, List l,Customer c){
        l.findInfo(bookingid,c.getCusid()).info.setStatus("SERVING");
    }
    
    public void cancel(int bookingid, List l,Customer c){
        if (l.findInfo(bookingid, c.getCusid()) != null && l.findInfo(bookingid, c.getCusid()).info.getStatus().equalsIgnoreCase("waiting")) {
            Node p = l.findInfo(bookingid, c.getCusid()).prev;
            Node q = l.findInfo(bookingid, c.getCusid()).next;
            if (p != null) {
                p.next = q;
            } else {
                l.head = q;
            }
            if (q != null) {
                q.prev = p;
            } else {
                l.tail = p;
            }
        }
    }
    
    public void cancelForAdmin(int bookingid, List l,int custid){
        if (l.findInfo(bookingid, custid) != null && !(l.findInfo(bookingid, custid).info.getStatus().equalsIgnoreCase("completed"))) {
            Node p = l.findInfo(bookingid, custid).prev;
            Node q = l.findInfo(bookingid, custid).next;
            if (p != null) {
                p.next = q;
            } else {
                l.head = q;
            }
            if (q != null) {
                q.prev = p;
            } else {
                l.tail = p;
            }
        }
    }
}
