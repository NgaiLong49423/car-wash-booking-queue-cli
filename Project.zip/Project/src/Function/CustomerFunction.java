/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Function;

import dto.Booking;
import dto.Customer;

/**
 *
 * @author Admin
 */
public class CustomerFunction {
    public void updatePoint(Customer c, List l, int bookingid){
        int newPoint = c.getCusid() + l.findInfo(bookingid,c.getCusid()).info.getPrice()/1000;
        c.setPoint(newPoint);
        if(newPoint>=2000 && newPoint<6000){
            c.setTier("Silver");
        }else if(newPoint>=6000 && newPoint<15000){
            c.setTier("Gold");
        }else if(newPoint>=15000){
            c.setTier("Platinum");
        }
    }
}
