/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Function;

import dto.Customer;
import dto.Node;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Admin
 */
public class FileFunction {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public void saveBooking(List l){
        try {
            FileWriter fw = new FileWriter("bookings.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            Node current = l.head;
            while(current!=null){
                String date = current.info.getBookingdate().format(formatter);
                pw.println(current.info.getId() + "," + current.info.getCusid() + "," + current.info.getCarid() + "," + date + "," + current.info.getStatus() + "," + current.info.getPrice());
                current = current.next;
            }
            pw.close();
        } catch (Exception e) {
            System.out.println("Error while saving");
        }
    }
    
    public void saveCustomer(Customer c){
        try {
            FileWriter fw = new FileWriter("customers.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.println(c.getCusid() + "," + c.getPassword() + "," + c.getPoint() + "," + c.getTier());
            pw.close();
        } catch (Exception e) {
            System.out.println("Error while saving");
        }
    }
}
