/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Function;

import dto.Booking;
import dto.Node;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Admin
 */
public class List {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public Node head,tail;
    
    public List(){
        head=tail=null;
    }
    
    public boolean isEmpty(){
        return(head==null);
    }
    
    public void clear(){
        head=tail=null;
    }
    
    public void add(Booking x){
        if(isEmpty()){
            head=tail=new Node(x,null,null);
        }else{
            Node q = new Node(x,tail,null);
            tail.next = q;
            tail = q;
        }
    }
    
    public Node findInfo(int bookingid, int cusid){
        Node result=null;
        Node current=head;
        while(current!=null){
            if(current.info.getId()==bookingid && current.info.getCusid()==cusid){
                result=current;
                break;
            }
            current=current.next;
        }
        return result;
    }
    
    public boolean findDate(String date){
        int count=0;
        Node current=head;
        while(current!=null){
            String bookdate = current.info.getBookingdate().format(formatter);
            if(date.equals(bookdate)){
                count += 1;
            }
            if(count==3){
                return false;
            }
            current=current.next;
        }
        return true;
    }
}
