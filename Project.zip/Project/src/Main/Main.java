/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Function.BookingFunction;
import Function.CustomerFunction;
import Function.FileFunction;
import Function.List;
import dto.Customer;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Customer c = new Customer(1, "a", 1000, "bronze");
        List l = new List();
        int lastsearchedid = 0;
        Customer prevstate = null;
        boolean confirmlastaction = false;
        BookingFunction bf = new BookingFunction();
        CustomerFunction cf = new CustomerFunction();
        FileFunction ff = new FileFunction();
        int choice = 0;
        do {
            choice = sc.nextInt();
            if (c.getTier().equalsIgnoreCase("admin")) {
                switch (choice) {
                    case 1:
                        System.out.println("Booking id: ");
                        int bookingid = sc.nextInt();
                        System.out.println("Customer id: ");
                        int custid = sc.nextInt();
                        bf.cancelForAdmin(bookingid, l, custid);
                        break;
                }
            } else {
                switch (choice) {
                    case 1:
                        bf.addBooking(l, c);
                        break;

                    case 2:
                        prevstate = c;
                        System.out.print("Booking id: ");
                        int bookingid = sc.nextInt();
                        lastsearchedid = bookingid;
                        if (bf.payment(bookingid, l, c)) {
                            cf.updatePoint(c, l, bookingid);
                            confirmlastaction=true;
                        }
                        break;

                    case 3:
                        if (prevstate != null && confirmlastaction==true) {
                            c = prevstate;
                            bf.undo(lastsearchedid, l, c);
                            confirmlastaction = false;
                        } else {
                            System.out.println("No previous action found");
                        }
                        break;
                    
                    case 4:
                        System.out.print("Booking id: ");
                        bookingid = sc.nextInt();
                        sc.nextLine();
                        bf.cancel(bookingid, l, c);
                }
            }
            ff.saveBooking(l);
            ff.saveCustomer(c);
        } while (choice > 0);
    }
    
}
