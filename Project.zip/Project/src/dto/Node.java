/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

/**
 *
 * @author Admin
 */
public class Node {
    public Booking info;
    public Node prev,next;

    public Node() {
    }

    public Node(Booking info, Node prev, Node next) {
        this.info = info;
        this.prev = prev;
        this.next = next;
    }
    
        
}
